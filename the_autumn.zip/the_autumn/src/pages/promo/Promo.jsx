import React from "react";

export default function Promo() {
  return (
    <>
      <p>Đây là màn hình Đơn giảm giá</p>
    </>
  );
}
