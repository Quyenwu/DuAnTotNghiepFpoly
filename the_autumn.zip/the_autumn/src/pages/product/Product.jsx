import React from 'react'

export default function Product() {
  return (
    <>
      <p>Đây là màn hình Sản phẩm</p>
    </>
  )
}
