import React from 'react'

export default function Statistical() {
  return (
    <>
      <p>Đây là màn hình Thống kê</p>
    </>
  )
}
