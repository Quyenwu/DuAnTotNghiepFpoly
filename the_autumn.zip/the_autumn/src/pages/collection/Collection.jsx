import React from 'react'

export default function Collection() {
  return (
    <>
      <p>Đây là màn hình Bộ sưu tập</p>
    </>
  )
}
