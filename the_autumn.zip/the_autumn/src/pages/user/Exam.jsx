import React from 'react'

export default function Exam() {
  return (
    <div>
        asdasd
    </div>
  )
}
