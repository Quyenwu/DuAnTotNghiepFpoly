import React from 'react'

export default function Category() {
  return (
    <>
      <p>Đây là màn hình Danh mục</p>
    </>
  )
}
