import React from 'react'

export default function Sell() {
  return (
    <>
      <p>Đây là màn hình Bán hàng</p>
    </>
  )
}
