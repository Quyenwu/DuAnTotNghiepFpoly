import React from 'react'

export default function Discount() {
  return (
    <>
      <p>Đây là màn hình Phiếu giảm giá</p>
    </>
  )
}
