import React from 'react'

export default function Bill() {
  return (
    <>
      <p>Đây là màn hình Hóa đơn</p>
    </>
  )
}
