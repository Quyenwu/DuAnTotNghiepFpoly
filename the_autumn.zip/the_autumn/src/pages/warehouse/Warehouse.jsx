import React from 'react'

export default function Warehouse() {
  return (
    <>
      <p>Đây là màn hình Kho hàng</p>
    </>
  )
}
